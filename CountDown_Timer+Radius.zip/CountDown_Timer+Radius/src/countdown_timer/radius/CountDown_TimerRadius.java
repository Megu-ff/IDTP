
package countdown_timer.radius;

import java.util.Timer;
import java.util.TimerTask;
import java.util.Scanner;

/*
 * @author x15314866
 */
public class CountDown_TimerRadius {
    
    static double timeRemaining;
    static Timer timer;
    static double totalTime;
    static double radius;
    
    //Realistically don't need theses two, useful for dev purposes though, remove at a later date
    static double percentageTotalTime;
    static double percentageRadius;
    
    
    static String gameType;
    static boolean bsc;
    static boolean nrm;
    static boolean adv;
    
    //For adv
    static double tickCount;
    static double radiusChange;
    static double RC_T;
    
    static double decayStart;
    static double decayEnd;
    static double DecayedRadius;
    
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        
        System.out.println("Please enter if you wish to play basic, normal or advanced mode.");
        
        while(bsc==false&&adv==false&&nrm==false){
            gameType = input.next();
            switch(gameType){
                case "basic": bsc=true;
                break;
                case "advanced": adv=true;
                break;
                case "normal": nrm=true;
            }
        }
        
        //Inputting desired time
        System.out.println("Input time here");
        totalTime = input.nextDouble();
        //Inputing desired radius
        System.out.println("Input radius here");
        radius = input.nextDouble();
        
        //Time in milliseconds at which task is to be executed
        int delay = 1000; 
        //Time in milliseconds between each execution
        int period = 1000;
        
        //
        timer = new Timer();
        timeRemaining = totalTime;
        //
        
        
        if(bsc==true){
            System.out.println("1 is true");
            //No Radius Decay
            //User will simply input Radius and Time
            timer.scheduleAtFixedRate(new TimerTask() {
                public void run() {
                    setTimeRemaining();
                    System.out.println((int)timeRemaining + " seconds remaining");
                }// End run()
            }, delay, period);
            //End timer
        }//End bsc boolean
        
        if(nrm==true){
            System.out.println("2 is true");
            //Radius Decay will be active, from 100% of Radius to 10% of Radius
            //This will happen from after the first 20% of time has gone by
            //And will gratuate to the minimum value until 20% of the time remains
            
            //tickCount is the variable for storing the amount of seconds that pass while decay is active
            //tickCount will always be 60% of total time, from 80 to 20
            tickCount = (((60)*(totalTime))/100);
            //radiusChagne is the variable for storing the distance reduced while decay is active
            //radiusChange will always be 90% as we are going from 100% to 10%
            radiusChange = (((90)*(radius))/100);

            System.out.println("tickCount: "+tickCount);
            System.out.println("radiusChange: "+radiusChange);

            //RC_T (RadiusChange/Tick) is the variable for storing the change in radius per second gone by
            RC_T = radiusChange/tickCount;
            System.out.println("RadiusChange/Tick: "+RC_T);
            
            timer.scheduleAtFixedRate(new TimerTask() {
                public void run() {
                    setRadiusNRM();
                    setTimeRemaining();
                    //Time Remainging as a %
                    percentageTotalTime = ((timeRemaining)/(totalTime))*100;
                    System.out.println(percentageTotalTime+"%"); //Currently non functional
                    System.out.println(timeRemaining+" Seconds"); //Currently non functional
                    System.out.println(radius+" metres");
                }// End run()
            }, delay, period);
            //End timer
            
        }//End nrm Boolean
        
        if(adv==true){
            System.out.println("3 is true");
            //Radius Decay will be active, the size and rate of decay will be of the users choosing
            //The decay will happen at a proportionate value to the inputted time
            //Will have to make 1% as the lower limit and not allow the user to input negative numbers
            //Achievable through the use of a GUI and Android Studio
            
            //Inputing desired radius decay timing percentage
            System.out.println("Start Radius Decay at this Percentage of Time");
            decayStart=input.nextDouble();
            System.out.println("End Radius Decay at this Percentage of Time");
            decayEnd=input.nextDouble();
            //Inputing desired radius decay amount percentage
            System.out.println("End Radius Decay from this Percentage of the total Radius");
            DecayedRadius=input.nextDouble();


            //tickCount is the variable for storing the amount of seconds that pass while decay is active
            tickCount = (((decayStart-decayEnd)*(totalTime))/100);
            //radiusChagne is the variable for storing the distance reduced while decay is active
            radiusChange = (((100-DecayedRadius)*(radius))/100);

            System.out.println("tickCount: "+tickCount);
            System.out.println("radiusChange: "+radiusChange);

            //RC_T (RadiusChange/Tick) is the variable for storing the change in radius per second gone by
            RC_T = radiusChange/tickCount;
            System.out.println("RadiusChange/Tick: "+RC_T);
            
            timer.scheduleAtFixedRate(new TimerTask() {
                public void run() {
                    setRadiusADV();
                    setTimeRemaining();
                    //Time Remainging as a %
                    percentageTotalTime = ((timeRemaining)/(totalTime))*100;
                    System.out.println(percentageTotalTime+"%"); //Currently non functional
                    System.out.println(timeRemaining+" Seconds"); //Currently non functional
                    System.out.println(radius+" metres");
                }// End run()
            }, delay, period);
            //End timer
            
        }//End adv boolean
        
    }//End main method
    
    private static final double setTimeRemaining() {
        if (timeRemaining == 1) {
            timer.cancel();
        }
        return --timeRemaining;
    }//End setTimeRemaining
    
    //Setting Radius decay and returning radius value as time passes
    private static final double setRadiusADV(){
        if(percentageTotalTime==decayEnd||percentageTotalTime<decayEnd){
            return radius;
        }
        else if(percentageTotalTime==decayStart||percentageTotalTime<decayStart){
            return radius=radius-RC_T;
        }
        else{
            return radius;
        }
    }//End
    
    private static final double setRadiusNRM(){
        if(percentageTotalTime==20||percentageTotalTime<20){
            return radius;
        }
        else if(percentageTotalTime==80||percentageTotalTime<80){
            return radius=radius-RC_T;
        }
        else{
            return radius;
        }
    }
}//End Class
